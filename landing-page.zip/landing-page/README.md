
Project Title
Landing Page Project

Getting Started
These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.


## Table of contents
* [General info](#general-info)
* [Technologies](#technologies)
* [Setup](#setup)

## General info
The starter project has some HTML and CSS styling  and javascript to display a dynamic sectional navigation version of the Landing Page project. 
This project was modified from a static version to an interactive version by modifying the HTML and CSS files, but primarily the JavaScript file.
## Technologies
Project is created with:
* HTML 5
* CSS 3
* JAVASCRIPT
* DOM
	
## Setup
To run this project, open the project folder and run the index file.