/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/
window.onscroll = function() {myFunction()};
window.onscroll = function() {mm()};
window.onload = function() {udd()};

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
// build the nav


// Add class 'active' to section when near top of viewport
 
// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click
function showDetails(xsection) {

  var sectionType = xsection.getAttribute("data-section-type");
  var gh = document.getElementById(sectionType);
var element = document.getElementById(sectionType);

  element.scrollIntoView();
}
// Set sections as active

// function to Dynamically create navbar links
 function udd() {
    var ss =document.getElementsByClassName('landing__container');
for (i=1;i<(ss.length+1);i++){
  var li= document.createElement('li');
  //code to Dynamically generate navbar links using iteration
li.innerHTML='<a href="javascript:void(0)" onclick ="javascript:showDetails(this)"  data-section-type="section'+i+'" id = sect'+ i +'>Section '+i+' &nbsp</a>';
document.getElementById('navbar__menu2').appendChild(li);
}
}

var el;
function mm(){
  //loops thru the available sections in the page
  var ss =document.getElementsByClassName('landing__container');
for (i=1;i<(ss.length+1);i++){
  var pp =document.getElementById("jack");
  // assigns the availlabe section number variable to the active view point seracher
el =document.getElementById("section"+i);
but =document.getElementById("Sect2");
if (isInViewport(el) == true){
  pp.innerHTML= 'section'+i;
}
}
}

// checks if element el is active in viewpoint
var isInViewport = function (el) {
  var bounding = el.getBoundingClientRect();
  return (
      bounding.top >= 0 &&
      bounding.left >= 0 &&
      bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      bounding.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
};